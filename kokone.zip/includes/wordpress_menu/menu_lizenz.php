<?php
/*
 * Excluded file that handles the Lizenz tab in the WordPress KRP admin menu
 */

function krp_lizenz_section_callback() {
    ?>
    <h2>Lizenz Status</h2>
    <?php
}
